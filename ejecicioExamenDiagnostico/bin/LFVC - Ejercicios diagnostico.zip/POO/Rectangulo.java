package POO;

public class Rectangulo {
	private int base;
	private int altura;
	
	public Rectangulo() {
		base = 0;
		altura = 0;
	}
	public void setBase(int nuevaBase) {
		base = nuevaBase;
	}
	
	public void setAltura(int nuevaAltura) {
		altura = nuevaAltura;
	}
	public int getBase() {
		return base;
	}
	
	public int getAltura() {
		return altura;
	}
	
	
}
