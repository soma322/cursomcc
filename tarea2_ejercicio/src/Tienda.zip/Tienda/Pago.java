package Tienda;

public interface Pago {
	void realizarPago(double cantidad);
}
