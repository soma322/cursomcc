package Tienda;

public class Productos {
	String nombre;
	int precio;
	int cantidad;
	
	public Productos(String nombre,	int precio,	int cantidad) {
		this.nombre = nombre;
		this.precio = precio;
		this.cantidad = cantidad;
	}
}
