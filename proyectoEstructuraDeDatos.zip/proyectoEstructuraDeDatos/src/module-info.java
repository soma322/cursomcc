/**
 * 
 */
/**
 * 
 */
module proyectoEstructuraDeDatos {
	requires org.json;
}